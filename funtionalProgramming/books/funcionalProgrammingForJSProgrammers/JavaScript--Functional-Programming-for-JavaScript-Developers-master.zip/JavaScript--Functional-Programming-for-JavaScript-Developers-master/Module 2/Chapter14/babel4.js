if(true)
{
	var outside = 9;
	let inside = 7;
}

console.log(outside);
console.log(inside);