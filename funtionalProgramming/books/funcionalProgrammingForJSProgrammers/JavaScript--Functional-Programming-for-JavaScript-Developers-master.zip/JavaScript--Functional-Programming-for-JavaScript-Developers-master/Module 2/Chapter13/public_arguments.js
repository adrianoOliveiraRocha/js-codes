class Axe {
    constructor(handleLength, headHeight) {
        this.handleLength = handleLength;
        this.headHeight = headHeight;
    }
}
