function CreateFeast(meat, drink = "wine"){
	console.log("The meat is: " + meat);
	console.log("The drink is: " + drink);
}
CreateFeast("Boar", "Beer"); 
CreateFeast("Venison");